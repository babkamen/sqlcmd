/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2014, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc3;

import org.postgresql.ds.PGSimpleDataSource;

public class Jdbc3SimpleDataSource extends PGSimpleDataSource
{
}
