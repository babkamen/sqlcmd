/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2014, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/

package org.postgresql.jdbc3;

import org.postgresql.ds.PGConnectionPoolDataSource;

public class Jdbc3ConnectionPool extends PGConnectionPoolDataSource
{
}
